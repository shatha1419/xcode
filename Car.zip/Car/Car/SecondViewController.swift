

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var member1Img: UIImageView!
    @IBOutlet weak var member2Img: UIImageView!
    @IBOutlet weak var member3Img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        member1Img.layer.cornerRadius = member1Img.frame.height / 2
        
        member2Img.layer.cornerRadius = member2Img.frame.height / 2
        
        member3Img.layer.cornerRadius = member3Img.frame.height / 2
    }
    
    

}
