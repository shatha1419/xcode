

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var minusBtn: UIButton!
    @IBOutlet weak var plusBtn: UIButton!
    @IBOutlet weak var homeAddressBtn: UIButton!
    
    var passengers = 1
    
    @IBOutlet weak var countLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        minusBtn.layer.cornerRadius = minusBtn.frame.height / 2
        
        plusBtn.layer.cornerRadius = plusBtn.frame.height / 2
        
        countLabel.text = "\(passengers)"
        
        homeAddressBtn.layer.cornerRadius = 16
    }
    
    @IBAction func incrementBtn(_ sender: Any) {
        
        passengers += 1
        
        countLabel.text = "\(passengers)"
    }
    
    @IBAction func decrementBtn(_ sender: Any) {
        
        passengers -= 1
        
        countLabel.text = "\(passengers)"
    }
    

}

